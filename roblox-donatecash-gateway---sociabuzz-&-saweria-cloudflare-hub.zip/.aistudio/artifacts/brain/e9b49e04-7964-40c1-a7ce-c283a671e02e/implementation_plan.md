# Roblox DonateCash Gateway — Instant Production Publish & Live Verifier

Implementasi alur publikasi instan (Instant Publish) yang memungkinkan pengguna memasukkan subdomain Cloudflare Worker mereka sendiri, menyalin perintah otomatis Wrangler CLI untuk terminal, serta melakukan pengujian langsung dengan tombol verifikasi live status yang terintegrasi ke game Roblox.

---

### User Review & Critical Decisions

> [!IMPORTANT]
> Berdasarkan jawaban klarifikasi yang telah Anda pilih:
> 1. **Subdomain Cloudflare Worker**: Pengguna akan diberikan input fleksibel untuk memasukkan subdomain / custom domain Worker milik sendiri (misal: `https://my-donate-worker.subdomain.workers.dev`), yang secara otomatis memperbarui URL webhook Saweria, Sociabuzz, dan BagiBagi.co di seluruh sistem.
> 2. **Metode Deploy**: Disediakan panduan terminal lengkap berbasis **Wrangler CLI** beserta file konfigurasi `wrangler.toml` dan skrip deploy sekali jalan (`npx wrangler deploy`).
> 3. **Verifikasi Status Live**: Ditambahkan **Tombol Publish Cepat & Live Status Health-Check** interaktif yang memvalidasi koneksi endpoint `/api/pull`, verifikasi debug token, status queue, dan kesiapan komunikasi ke Roblox Server.

---

### 1. Overview & Core Concept

- **Tujuan Utama**: Memastikan aplikasi siap dipublikasikan dan langsung berfungsi di lingkungan produksi nyata tanpa kebingungan konfigurasi.
- **Target Pengguna**: Pemilik game Roblox (Owner), Lead Developer, dan Admin yang ingin mengintegrasikan pembayaran Saweria, Sociabuzz, dan BagiBagi.co secara aman ke dalam game mereka melalui Cloudflare Worker.
- **Nilai Tambah**:
  - Konfigurasi URL dinamis: Mengubah satu subdomain Worker akan otomatis menyinkronkan seluruh URL webhook dan parameter runtime.
  - Skrip terminal siap salin: Perintah `npx wrangler deploy` dengan environment variables (`DEBUG_TOKEN`, `API_KEY`, dsb.) terkonfigurasi.
  - Live Inspector & Health-Check: Modal / banner verifikasi koneksi dengan status indikator hijau ketika Worker dan Roblox telah terhubung.

---

### 2. User Experience & Visual Design

#### A. Key User Flows
1. **Atur Subdomain Worker**: Pengguna memasukkan URL Worker mereka di tab Cloudflare Worker atau modal "Publish ke Live".
2. **Deploy via Wrangler CLI**: Pengguna mengklik tombol salin perintah terminal (`npx wrangler deploy`) dan file `wrangler.toml`.
3. **Uji Koneksi & Publish**: Pengguna menekan tombol **"Verifikasi & Publish Live"**, sistem memicu ping live ke endpoint `/health` dan `/api/pull`, lalu menampilkan status sukses beserta konfirmasi kesiapan integrasi Roblox.
4. **Pasang Webhook**: Pengguna menyalin URL webhook yang sudah disesuaikan dengan subdomain mereka ke dashboard Saweria, Sociabuzz, dan BagiBagi.co.

#### B. Visual Identity & Theme
- **Gaya Visual**: Developer Console bertema gelap (Dark Slate `#0B0F19`), beraksen Indigo (`#6366F1`), Amber (`#F59E0B`), dan Emerald (`#10B981`).
- **Tipografi**: Heading display menggunakan `Plus Jakarta Sans`, teks tabular/angka/kode menggunakan `JetBrains Mono` (`font-mono tabular-nums`).
- **Disiplin Desain**:
  - Tanpa pill badge berlebih, teks metadata bersih dengan pemisah titik (`·`).
  - Top navigation bar mengikuti kontrak 3-zona (Brand — Navigasi Tab — Tombol Aksi Cepat "🚀 Publish ke Live").
  - Tidak ada komponen palsu atau telemetry palsu; semua tombol memiliki handler aktif.

---

### 3. Key Product Decisions & Trade-Offs

- **Keputusan 1: Penyimpanan Subdomain & URL Worker di Local Storage / State**
  - *Pendekatan*: Menyimpan URL Worker yang dimasukkan pengguna secara reaktif ke state aplikasi dan `localStorage`, sehingga langsung merefleksikan perubahan ke URL Webhook Saweria, Sociabuzz, BagiBagi.co, dan skrip `YMADonateRealRuntime.lua`.
  - *Alasan*: Pengguna tidak perlu mengedit file kode secara manual untuk mengganti nama domain Worker mereka.
- **Keputusan 2: Deployment via Wrangler CLI vs Quick Edit**
  - *Pendekatan*: Menyediakan file `wrangler.toml` lengkap dengan variabel lingkungan dan instruksi terminal 2 langkah (`npm install -g wrangler` dan `wrangler deploy`).
  - *Alasan*: Sesuai pilihan pengguna, metode Wrangler CLI lebih aman untuk tim developer dan mendukung otomatisasi CI/CD.
- **Keputusan 3: Modal Verifikasi Status Live Interaktif**
  - *Pendekatan*: Menampilkan dialog popup khusus dengan checklist pengujian:
    1. Endpoint `/health` merespons 200 OK.
    2. Endpoint `/api/pull` siap menerima polling dari Roblox.
    3. Debug token valid (`x-debug-token`).
    4. Webhook Saweria, Sociabuzz, dan BagiBagi.co siap menerima payload.

---

### 4. Technical Architecture & Data Strategy

```
┌─────────────────────────────────────────────────────────────┐
│                    Roblox DonateCash Hub                    │
│                                                             │
│  ┌─────────────────┐   ┌─────────────────┐   ┌────────────┐ │
│  │   Input Domain  │──>│  Revenue Split  │──>│ Simulator  │ │
│  │ & Publish Modal │   │ & Webhook Hub   │   │  In-Game   │ │
│  └────────┬────────┘   └────────┬────────┘   └─────┬──────┘ │
└───────────┼─────────────────────┼──────────────────┼────────┘
            │                     │                  │
            ▼                     ▼                  ▼
┌─────────────────────────────────────────────────────────────┐
│               Cloudflare Worker (worker.js)                 │
│                                                             │
│  • POST /webhook/saweria    • POST /api/pull  (Roblox Poll) │
│  • POST /webhook/sociabuzz   • POST /api/ack   (Roblox Ack)  │
│  • POST /webhook/bagibagi   • GET  /debug/queue (Admin)     │
│  • POST /debug/push         • Discord Embed Dispatcher      │
└──────────────────────────┬──────────────────────────────────┘
                           │
                           ▼
┌─────────────────────────────────────────────────────────────┐
│             Roblox Game Server (ServerScriptService)        │
│                                                             │
│  • YMADonateRealSecrets.lua (ApiKey, DebugToken, Admins)   │
│  • YMADonateRealRuntime.lua (HttpService Polling Loop, 4s)  │
└─────────────────────────────────────────────────────────────┘
```

#### Komponen yang Diperbarui:
1. **`Navbar.tsx`**: Tombol aksi utama "🚀 Publish ke Live" dengan modal ringkasan status publikasi.
2. **`CloudflareTab.tsx`**: Input field untuk custom subdomain Worker, instruksi lengkap Wrangler CLI, dan live health checker.
3. **`WebhooksTab.tsx`**: Sinkronisasi otomatis URL webhook Saweria, Sociabuzz, dan BagiBagi.co berdasarkan subdomain kustom pengguna.
4. **`PublishModal.tsx`**: Modal interaktif baru untuk memverifikasi kesiapan live, menyalin kredensial, dan memastikan game Roblox siap menerima donasi real-time.
